import { motion } from "motion/react";
import { 
  Menu, 
  AlertTriangle, 
  Sparkles, 
  Webhook, 
  Brain, 
  Package, 
  Bot, 
  CheckCircle2,
  Github,
  ExternalLink,
  ArrowRight
} from "lucide-react";

const Navbar = () => (
  <nav className="fixed top-0 w-full z-50 bg-surface/80 backdrop-blur-xl flex items-center justify-between px-8 py-4 max-w-full shadow-[0px_20px_40px_rgba(34,211,238,0.08)]">
    <div className="text-xl font-bold tracking-tighter text-primary font-headline">
      Agentic Sales Driver
    </div>
    <div className="hidden md:flex gap-8 items-center">
      <a className="text-secondary font-bold font-headline tracking-tight hover:text-secondary transition-colors duration-300" href="#">Case Study</a>
      <a className="text-primary/60 font-headline tracking-tight hover:text-secondary transition-colors duration-300" href="#">Architecture</a>
      <a className="text-primary/60 font-headline tracking-tight hover:text-secondary transition-colors duration-300" href="#">API Docs</a>
      <button className="bg-linear-to-br from-secondary to-tertiary-container text-on-primary px-6 py-2 rounded-full text-sm font-bold hover:shadow-[0_0_15px_rgba(93,230,255,0.4)] transition-all cursor-pointer">
        Hire Developer
      </button>
    </div>
    <div className="md:hidden">
      <Menu className="text-secondary w-6 h-6" />
    </div>
  </nav>
);

const Hero = () => (
  <section className="min-h-[80vh] flex flex-col justify-center px-8 md:px-24 mb-32 relative overflow-hidden">
    <div className="absolute top-1/4 -right-20 w-96 h-96 bg-secondary/10 blur-[120px] rounded-full"></div>
    <div className="absolute bottom-1/4 -left-20 w-96 h-96 bg-tertiary/10 blur-[120px] rounded-full"></div>
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.8 }}
      className="max-w-5xl z-10"
    >
      <span className="text-secondary font-label tracking-[0.2em] uppercase text-xs mb-6 block">Agentic Systems Division // Project 01</span>
      <h1 className="text-5xl md:text-7xl font-headline font-bold text-on-surface tracking-tighter leading-[1.1] mb-8">
        Agentic Sales Driver: Autonomous AI for <span className="text-gradient-cyan-purple">WhatsApp-Based</span> Retail Selling
      </h1>
      <p className="text-xl md:text-2xl text-on-surface-variant font-light leading-relaxed max-w-3xl">
        An AI-powered system that converts customer messages into sales by understanding intent, checking inventory, and responding like a human sales assistant.
      </p>
      <div className="mt-12 flex flex-wrap gap-4">
        <button className="bg-linear-to-br from-secondary to-tertiary-container text-on-primary px-8 py-4 rounded-full font-bold text-lg hover:scale-[1.02] active:scale-95 transition-all cursor-pointer flex items-center gap-2">
          View Live Demo <ExternalLink className="w-5 h-5" />
        </button>
        <button className="glass-panel border border-secondary/20 text-secondary px-8 py-4 rounded-full font-bold text-lg hover:bg-secondary/10 transition-all cursor-pointer flex items-center gap-2">
          GitHub Repository <Github className="w-5 h-5" />
        </button>
      </div>
    </motion.div>
  </section>
);

const BentoGrid = () => (
  <section className="px-8 md:px-24 mb-32">
    <div className="grid grid-cols-1 md:grid-cols-12 gap-8">
      <motion.div 
        whileInView={{ opacity: 1, x: 0 }}
        initial={{ opacity: 0, x: -20 }}
        viewport={{ once: true }}
        className="md:col-span-5 bg-surface-container-low rounded-xl p-10 flex flex-col justify-between border border-outline-variant/10"
      >
        <div>
          <AlertTriangle className="text-error mb-6 w-10 h-10" />
          <h2 className="text-3xl font-headline font-bold mb-6 tracking-tight">The Bottleneck</h2>
          <ul className="space-y-4 text-on-surface-variant leading-relaxed">
            <li className="flex items-start gap-3"><span className="text-error font-bold">•</span> Manual, delayed responses lead to 60% lead drop-off.</li>
            <li className="flex items-start gap-3"><span className="text-error font-bold">•</span> Zero attribution tracking for chat-based sales.</li>
            <li className="flex items-start gap-3"><span className="text-error font-bold">•</span> Scaling requires massive human support teams.</li>
            <li className="flex items-start gap-3"><span className="text-error font-bold">•</span> No intelligence layer between data and customer.</li>
          </ul>
        </div>
      </motion.div>
      <motion.div 
        whileInView={{ opacity: 1, x: 0 }}
        initial={{ opacity: 0, x: 20 }}
        viewport={{ once: true }}
        className="md:col-span-7 bg-primary-container rounded-xl p-10 relative overflow-hidden group"
      >
        <div className="absolute inset-0 bg-linear-to-br from-secondary/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity"></div>
        <Sparkles className="text-secondary mb-6 w-10 h-10" />
        <h2 className="text-3xl font-headline font-bold mb-6 tracking-tight">The Agentic Architecture</h2>
        <p className="text-lg text-on-surface leading-relaxed mb-8">
          I built an Agentic Sales Driver — an AI-powered backend system that parses messages, extracts intent and structured data with LLMs, matches inventory, and responds contextually.
        </p>
        <div className="flex flex-wrap gap-3">
          {["Autonomous", "Context-Aware", "Inventory-Synced"].map((tag) => (
            <span key={tag} className="bg-surface-container-highest px-4 py-2 rounded-lg text-xs font-label uppercase tracking-widest text-secondary">
              {tag}
            </span>
          ))}
        </div>
      </motion.div>
    </div>
  </section>
);

const LogicFlow = () => {
  const steps = [
    {
      id: "01",
      title: "Webhook/API Intake",
      desc: "Real-time message ingestion via WhatsApp Cloud API hooks into the FastAPI listener.",
      icon: <Webhook className="text-secondary w-6 h-6" />
    },
    {
      id: "02",
      title: "LLM Intent Parsing",
      desc: "Unstructured text is converted to structured JSON schemas (Size, Color, Product ID, Intent).",
      icon: <Brain className="text-secondary w-6 h-6" />
    },
    {
      id: "03",
      title: "Inventory Check",
      desc: "System queries MongoDB/PostgreSQL to verify real-time stock availability and pricing.",
      icon: <Package className="text-secondary w-6 h-6" />
    },
    {
      id: "04",
      title: "AI Response Generation",
      desc: "Agent generates a natural, brand-voice response and executes the auto-send command.",
      icon: <Bot className="text-secondary w-6 h-6" />
    }
  ];

  return (
    <section className="px-8 md:px-24 mb-32">
      <h2 className="text-4xl font-headline font-bold mb-16 text-center">Operational Logic Flow</h2>
      <div className="max-w-4xl mx-auto space-y-12">
        {steps.map((step, idx) => (
          <motion.div 
            key={step.id}
            whileInView={{ opacity: 1, y: 0 }}
            initial={{ opacity: 0, y: 20 }}
            viewport={{ once: true }}
            transition={{ delay: idx * 0.1 }}
            className="flex items-center gap-8 group"
          >
            <div className="w-16 h-16 rounded-full bg-surface-container-high border border-secondary/30 flex items-center justify-center shrink-0 group-hover:scale-110 transition-transform">
              {step.icon}
            </div>
            <div className={`flex-grow pb-8 ${idx !== steps.length - 1 ? 'border-b border-outline-variant/10' : ''}`}>
              <h3 className="text-xl font-bold font-headline mb-2">{step.id}. {step.title}</h3>
              <p className="text-on-surface-variant">{step.desc}</p>
            </div>
          </motion.div>
        ))}
      </div>
    </section>
  );
};

const TechStack = () => {
  const techs = [
    { name: "FastAPI", role: "The Backbone" },
    { name: "MongoDB", role: "State Memory" },
    { name: "OpenAI", role: "Reasoning" },
    { name: "Streamlit", role: "Control Panel" },
    { name: "AWS", role: "Infrastructure" },
    { name: "Meta", role: "Channel" }
  ];

  return (
    <section className="px-8 md:px-24 mb-32 bg-surface-container-lowest py-24 -mx-0">
      <div className="max-w-7xl mx-auto">
        <div className="flex flex-col md:flex-row justify-between items-end mb-16 gap-4">
          <h2 className="text-4xl font-headline font-bold">Technological Core</h2>
          <p className="text-secondary font-label text-sm uppercase tracking-widest">Built for production-grade reliability</p>
        </div>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-6">
          {techs.map((tech) => (
            <motion.div 
              key={tech.name}
              whileHover={{ scale: 1.05 }}
              className="bg-surface-container-low p-6 rounded-xl border border-secondary/10 hover:border-secondary/40 transition-all text-center group"
            >
              <span className="block text-2xl font-bold mb-2 group-hover:text-secondary">{tech.name}</span>
              <span className="text-xs text-on-surface-variant/60 font-label">{tech.role}</span>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

const Features = () => (
  <section className="px-8 md:px-24 mb-32 grid grid-cols-1 md:grid-cols-2 gap-24 items-center">
    <motion.div
      whileInView={{ opacity: 1, x: 0 }}
      initial={{ opacity: 0, x: -20 }}
      viewport={{ once: true }}
    >
      <h2 className="text-5xl font-headline font-bold mb-12 leading-tight">Engineered for<br/><span className="text-tertiary">Precision Selling</span></h2>
      <div className="space-y-8">
        {[
          { title: "Autonomous Chat", desc: "Handles end-to-end sales conversations without human intervention unless requested." },
          { title: "NL Product Extraction", desc: "Automatically identifies specific SKUs from natural language descriptions or typos." },
          { title: "Real-time Inventory", desc: "Zero latency lookups ensuring the agent never sells out-of-stock items." }
        ].map((feature) => (
          <div key={feature.title} className="flex gap-6">
            <CheckCircle2 className="text-secondary w-6 h-6 shrink-0 mt-1" />
            <div>
              <h4 className="text-xl font-bold mb-2">{feature.title}</h4>
              <p className="text-on-surface-variant">{feature.desc}</p>
            </div>
          </div>
        ))}
      </div>
    </motion.div>
    <div className="relative">
      <motion.div 
        whileInView={{ opacity: 1, scale: 1 }}
        initial={{ opacity: 0, scale: 0.9 }}
        viewport={{ once: true }}
        className="aspect-square bg-surface-container-high rounded-xl overflow-hidden glass-panel border border-outline-variant/10 p-8 flex items-center justify-center relative"
      >
        <div className="absolute inset-0 bg-linear-to-tr from-secondary/10 to-tertiary/10"></div>
        <img 
          className="rounded-lg shadow-2xl relative z-10 w-4/5 transform rotate-2" 
          alt="Modern smartphone interface" 
          src="https://lh3.googleusercontent.com/aida-public/AB6AXuB0DpQ_-3gM8Jhri9t4En0Vo_PaQgjtw7ULtPYKWs8bwCQwCMoWvWRKgwaDVQ-olC3Eq5jw2BbDM1fB5khdy7CHQo_EuKbU8AGub29F5ctVHsjNPRxlraaJRcX-l8BXkFx3X83ttAA_vedHKBT72EvINnOgm2arSXWkdVxuZ_wccl5FRcck4VV2rqbGqAvJnaT5rhcBJPlp4CQPdbRZUchhi_eBS10hu1qG7WOKTOEKkKW4VegXcR-vlLwJN-bIFwW5GCb6zGanvEmy"
          referrerPolicy="no-referrer"
        />
      </motion.div>
      <div className="absolute -bottom-8 -left-8 bg-primary-container p-6 rounded-xl border border-secondary/20 z-20 hidden md:block">
        <p className="text-4xl font-bold text-secondary font-headline">94%</p>
        <p className="text-xs uppercase tracking-widest font-label text-on-surface-variant">Accuracy Rate</p>
      </div>
    </div>
  </section>
);

const ChallengesRoadmap = () => (
  <section className="px-8 md:px-24 mb-32 grid grid-cols-1 md:grid-cols-2 gap-16">
    <motion.div 
      whileInView={{ opacity: 1, y: 0 }}
      initial={{ opacity: 0, y: 20 }}
      viewport={{ once: true }}
      className="glass-panel p-12 rounded-xl border border-outline-variant/10"
    >
      <h3 className="text-2xl font-headline font-bold mb-8 text-secondary tracking-tight">Technical Hurdles Overcome</h3>
      <div className="space-y-6">
        {[
          { id: "01", text: "Managing high-ambiguity slang and unstructured local dialect in customer messages." },
          { id: "02", text: "Maintaining conversation context across multiple sessions and days." },
          { id: "03", text: "Hard-guarding the LLM to prevent inventory hallucination or false promises." }
        ].map((challenge) => (
          <div key={challenge.id}>
            <p className="font-bold text-sm uppercase tracking-tighter text-on-surface/40 mb-2">Challenge {challenge.id}</p>
            <p className="text-lg">{challenge.text}</p>
          </div>
        ))}
      </div>
    </motion.div>
    <motion.div 
      whileInView={{ opacity: 1, y: 0 }}
      initial={{ opacity: 0, y: 20 }}
      viewport={{ once: true }}
      className="flex flex-col justify-center"
    >
      <h3 className="text-2xl font-headline font-bold mb-8 tracking-tight">Future Roadmap</h3>
      <ul className="space-y-4">
        {[
          "Direct UPI payment link generation",
          "Personalized recommendation engine based on history",
          "Multi-language support (Regional Dialects)",
          "Fine-tuned Llama-3 models for cost reduction"
        ].map((item) => (
          <li key={item} className="flex items-center gap-4 text-on-surface-variant">
            <span className="w-2 h-2 rounded-full bg-tertiary"></span> {item}
          </li>
        ))}
      </ul>
    </motion.div>
  </section>
);

const CTA = () => (
  <section className="px-8 md:px-24 pb-32">
    <motion.div 
      whileInView={{ scale: 1, opacity: 1 }}
      initial={{ scale: 0.95, opacity: 0 }}
      viewport={{ once: true }}
      className="bg-linear-to-br from-primary-container to-surface-container-low rounded-xl p-16 text-center border border-secondary/10 relative overflow-hidden"
    >
      <div className="absolute -top-24 -left-24 w-64 h-64 bg-secondary/5 blur-[80px] rounded-full"></div>
      <div className="relative z-10 max-w-2xl mx-auto">
        <h2 className="text-4xl md:text-5xl font-headline font-bold mb-8">Let's build the unseen future.</h2>
        <p className="text-xl text-on-surface-variant mb-12">Currently accepting select projects for agentic system design and AI infrastructure.</p>
        <button className="bg-on-surface text-surface px-12 py-5 rounded-full text-xl font-bold hover:bg-secondary hover:text-on-secondary transition-all cursor-pointer flex items-center gap-3 mx-auto">
          Start a Conversation <ArrowRight className="w-6 h-6" />
        </button>
      </div>
    </motion.div>
  </section>
);

const Footer = () => (
  <footer className="bg-surface w-full border-t border-primary/10 flex flex-col md:flex-row justify-between items-center px-12 py-16 gap-8">
    <div className="flex flex-col gap-2">
      <span className="text-lg font-black text-primary font-headline">Ethereal Architect</span>
      <p className="text-sm text-primary/40 font-body">© 2024 Ethereal Architect | Agentic Systems Division</p>
    </div>
    <div className="flex gap-12">
      {["Documentation", "Architecture", "GitHub", "Contact"].map((link) => (
        <a key={link} className="text-primary/40 hover:text-tertiary transition-all duration-300 font-body text-sm" href="#">{link}</a>
      ))}
    </div>
  </footer>
);

export default function App() {
  return (
    <div className="min-h-screen bg-surface selection:bg-secondary/30">
      <Navbar />
      <main className="pt-24">
        <Hero />
        <BentoGrid />
        <LogicFlow />
        <TechStack />
        <Features />
        <ChallengesRoadmap />
        <CTA />
      </main>
      <Footer />
    </div>
  );
}
